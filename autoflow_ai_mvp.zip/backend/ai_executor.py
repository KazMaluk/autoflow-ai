import openai
import os

def execute_task(command: str):
    openai.api_key = os.getenv("OPENAI_API_KEY")
    if not openai.api_key:
        raise ValueError("Missing OpenAI API Key. Set OPENAI_API_KEY in environment variables.")
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "system", "content": "Execute the following task."},
                      {"role": "user", "content": command}]
        )
        return response['choices'][0]['message']['content']
    except Exception as e:
        raise RuntimeError(f"Error executing task: {str(e)}")
