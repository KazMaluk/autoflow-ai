import { useState } from 'react';
import CommandInput from '../components/CommandInput';
import ResultDisplay from '../components/ResultDisplay';

export default function Home() {
    const [result, setResult] = useState('');

    const handleCommandSubmit = async (command) => {
        try {
            if (!command.trim()) {
                setResult("Error: Command cannot be empty.");
                return;
            }
            const response = await fetch('http://localhost:8000/execute', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ command })
            });
            if (!response.ok) throw new Error('Failed to execute command');
            const data = await response.json();
            setResult(data.result);
        } catch (error) {
            setResult(`Error: ${error.message}`);
        }
    };

    return (
        <div>
            <h1>AutoFlow AI</h1>
            <CommandInput onSubmit={handleCommandSubmit} />
            <ResultDisplay result={result} />
        </div>
    );
}
