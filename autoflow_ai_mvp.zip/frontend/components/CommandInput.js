import { useState } from 'react';

export default function CommandInput({ onSubmit }) {
    const [input, setInput] = useState('');

    const handleSubmit = () => {
        if (input.trim() === '') return;
        onSubmit(input);
        setInput('');
    };

    return (
        <div>
            <input 
                type="text" 
                value={input} 
                onChange={(e) => setInput(e.target.value)} 
                placeholder="Enter a command..." 
            />
            <button onClick={handleSubmit}>Execute</button>
        </div>
    );
}
