export default function ResultDisplay({ result }) {
    return (
        <div>
            <h2>Result:</h2>
            <p>{result || "Awaiting command..."}</p>
        </div>
    );
}
